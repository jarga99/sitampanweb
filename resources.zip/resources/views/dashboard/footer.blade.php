<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; 2022 <a href="#">Jarga99</a></strong> Sistem Informasi Tanam dan Panen
</footer>
